# Coding Exercise: CSS Positioning
UCBA Web Design 2 - Professor Eric Anderson

Coding exercise demonstrating CSS positioning properties
