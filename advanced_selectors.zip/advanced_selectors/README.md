# Coding Exercise: Advanced Selectors
### Coding Exercise: Advanced Selectors

 This coding exercise demonstrates how to use **attribute selectors, pseudo classes, pseudo elements, and some of the other advanced selectors** that have been recently added to CSS
